<?php
$HOST="pgsql2";
$PORT=5432;
$DTBS="tpcurseurs";
$USER="tpcurseurs";
$PASS="tpcurseurs"; 

$DETAILS=1;

?>
