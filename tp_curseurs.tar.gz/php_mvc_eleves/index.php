<?php

include("services_view.php");

html_header();

?>
<p><a href='solution1.php'>Solution 1 (jointure)</a></p>
<p><a href='solution2.php'>Solution 2 (plusieurs requêtes)</a></p>


<?php

html_footer();


?>
